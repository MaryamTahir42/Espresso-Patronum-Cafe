﻿namespace EspressoPatronum.Models.Entities
{
    public class Product
    {
        public int Id { get; set; }
        public string pname { get; set; }
        public string price { get; set; }   
        public string category { get; set; }
        public string description { get; set; }
    }
}
